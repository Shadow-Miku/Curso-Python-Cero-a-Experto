class DispositivoEntrada:
    # Constructor
    def __init__(self, marca, tipo_entrada):
        self.marca = marca
        self.tipo_entrada = tipo_entrada
    